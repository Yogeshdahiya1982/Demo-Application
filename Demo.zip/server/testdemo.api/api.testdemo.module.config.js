﻿module.exports = {
    route: 'testdemo.api',
    section: ['testapi'],
    controll: 'controller'
};