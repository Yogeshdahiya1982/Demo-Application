﻿module.exports = {
    test: require('./testservice.js'),
};