export class DemoInfo {
    num1: number;
    num2:number;
    result:number;
}