import { Component } from '@angular/core';

@Component({
  selector: 'app-demo-root',
  template: '<router-outlet></router-outlet>'
})
export class AppComponent {
  title = 'Demo Testing Application';
}
